#ifndef __INET_ETHERFRAME_H_
#define __INET_ETHERFRAME_H_


#include "EtherFrame_m.h"


#endif // __INET_ETHERFRAME_H_
